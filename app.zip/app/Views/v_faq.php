<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini Halaman Faq
<?= $this->endSection() ?>