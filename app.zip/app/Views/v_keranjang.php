<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<section class="section">
    <?php if (empty($keranjang)): ?>
        <p>Keranjang Anda kosong.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php foreach ($keranjang as $item): ?>
                    <tr>
                        <td><img src="<?= base_url($item['gambar']) ?>" alt="<?= $item['nama'] ?>" style="width: 50px; height: 50px; object-fit: cover;"></td>
                        <td><?= $item['nama'] ?></td>
                        <td>Rp <?= number_format($item['harga'], 0, ',', '.') ?></td>
                        <td><?= $item['qty'] ?></td>
                        <td>Rp <?= number_format($item['harga'] * $item['qty'], 0, ',', '.') ?></td>
                        <td>
                            <a href="<?= base_url('keranjang/hapus/' . $item['id']) ?>" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                    <?php $total += $item['harga'] * $item['qty']; ?>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="4">Total</th>
                    <th>Rp <?= number_format($total, 0, ',', '.') ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>
    <a href="<?= base_url('produk') ?>" class="btn btn-secondary">Kembali ke Produk</a>
</section>

<?= $this->endSection() ?>