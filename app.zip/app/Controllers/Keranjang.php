<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keranjang extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
    }

    // Menambahkan produk ke keranjang
    public function tambah() {
        $produk_id = $this->input->post('produk_id');
        $nama = $this->input->post('nama');
        $harga = $this->input->post('harga');
        $gambar = $this->input->post('gambar');

        $item = array(
            'id' => $produk_id,
            'nama' => $nama,
            'harga' => $harga,
            'gambar' => $gambar,
            'qty' => 1
        );

        $keranjang = $this->session->userdata('keranjang') ? $this->session->userdata('keranjang') : array();

        $index = -1;
        foreach ($keranjang as $key => $val) {
            if ($val['id'] == $produk_id) {
                $index = $key;
                break;
            }
        }

        if ($index >= 0) {
            $keranjang[$index]['qty'] += 1;
        } else {
            $keranjang[] = $item;
        }

        $this->session->set_userdata('keranjang', $keranjang);
        redirect('keranjang/lihat');
    }

    // Menampilkan isi keranjang
    public function lihat() {
        $data['keranjang'] = $this->session->userdata('keranjang') ? $this->session->userdata('keranjang') : array();
        $this->load->view('layout', $data);
    }

    // Hapus item dari keranjang
    public function hapus($id) {
        $keranjang = $this->session->userdata('keranjang');
        foreach ($keranjang as $key => $val) {
            if ($val['id'] == $id) {
                unset($keranjang[$key]);
                break;
            }
        }
        $keranjang = array_values($keranjang);
        $this->session->set_userdata('keranjang', $keranjang);
        redirect('keranjang/lihat');
    }
}